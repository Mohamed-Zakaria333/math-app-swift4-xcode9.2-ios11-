//
//  ViewController.swift
//  Math_test
//
//  Created by m on 7/25/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class levels: UIViewController {
var strct_obj2 = degree_array.deg_arry
var main_obj1 = Main()
    //array = 10 elemwnts
    // each element = 15
    //let preLoadArray:[Int] = Array(repeating: 15 , count: 10)
    // OR let preLoadArray2 = Array(repeating: 15 , count: 10)
var my_BTN_arr = [UIButton]()
let max_grade = 2
var flag = 0
 var levels_names = ["level 1","level 2","level 3","level 4","level 5","level 6","level 7","level 8","level 9","level 10","level 11","level 12"]
//==========================================
@IBOutlet weak var Lev1: UIButton!
@IBOutlet weak var Lev2: UIButton!
@IBOutlet weak var Lev3: UIButton!
@IBOutlet weak var Lev4: UIButton!
@IBOutlet weak var Lev5: UIButton!
@IBOutlet weak var Lev6: UIButton!
@IBOutlet weak var Lev7: UIButton!
@IBOutlet weak var Lev8: UIButton!
@IBOutlet weak var Lev9: UIButton!
@IBOutlet weak var Lev10: UIButton!
@IBOutlet weak var Lev11: UIButton!
@IBOutlet weak var Lev12: UIButton!
//==========================================
    override func viewDidLoad() {
        super.viewDidLoad()
        my_BTN_arr.append(Lev1)
        my_BTN_arr.append(Lev2)
        my_BTN_arr.append(Lev3)
        my_BTN_arr.append(Lev4)
        my_BTN_arr.append(Lev5)
        my_BTN_arr.append(Lev6)
        my_BTN_arr.append(Lev7)
        my_BTN_arr.append(Lev8)
        my_BTN_arr.append(Lev9)
        my_BTN_arr.append(Lev10)
        my_BTN_arr.append(Lev11)
        my_BTN_arr.append(Lev12)
    }
//==========================================
    override func viewDidAppear(_ animated: Bool) {
        print("=============================")
        print (degree_array.deg_arry)
        open_level()
    }
    
    
    
    @IBAction func GO_level(_sender: UIButton)
    {
        if (_sender.alpha == 1)
        {
         if(_sender.currentTitle == "level 1"&&degree_array.deg_arry[0] == max_grade)
         {
          let main_tab =  self.tabBarController?.viewControllers![0] as! Main
          main_tab.replay_view.isHidden = false
          main_tab.replay_level_label.text = degree_array.levels_Names[0]
          self.tabBarController?.selectedIndex = 0
          }
            else
         {
          self.tabBarController?.selectedIndex = 0
       }
        }
        else
        {
             shoud_pass_level()
        }
    }
//==========================================
    @IBAction func back()
    {
        self.tabBarController?.selectedIndex = 0
    }
//==========================================
    func shoud_pass_level()
    {
        
        let myalert = UIAlertController(title: "Read ME!", message: "You shoud pass level", preferredStyle: .alert)
        let myaction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        myalert.addAction(myaction)
        present(myalert, animated: true, completion: nil)
        
    }
    func open_level()
    {
        if(degree_array.deg_arry[flag] == max_grade)
        {
            
            my_BTN_arr[flag+1].alpha = 1
            my_BTN_arr[flag+1].setImage(UIImage(named: ""), for: .normal)
            flag+=1
        }
        
    }
    


}

