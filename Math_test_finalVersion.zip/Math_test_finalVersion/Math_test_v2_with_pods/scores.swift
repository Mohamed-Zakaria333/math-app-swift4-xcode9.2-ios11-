//
//  ViewController.swift
//  Math_test
//
//  Created by m on 7/25/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit

class scores: UIViewController {
@IBOutlet weak var degree_Lev1: UILabel?
@IBOutlet weak var degree_Lev2: UILabel?
@IBOutlet weak var degree_Lev3: UILabel?
@IBOutlet weak var degree_Lev4: UILabel?
@IBOutlet weak var degree_Lev5: UILabel?
@IBOutlet weak var degree_Lev6: UILabel?
@IBOutlet weak var degree_Lev7: UILabel?
@IBOutlet weak var degree_Lev8: UILabel?
@IBOutlet weak var degree_Lev9: UILabel?
@IBOutlet weak var degree_Lev10: UILabel?
@IBOutlet weak var degree_Lev11: UILabel?
@IBOutlet weak var degree_Lev12: UILabel?
    //***************
let max_num = "/2"
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
}
    override func viewDidAppear(_ animated: Bool) {

        print(degree_array.deg_arry)
        print("=============================")
        degree_Lev1?.text = String(degree_array.deg_arry[0])+max_num
        degree_Lev2?.text = String(degree_array.deg_arry[1])+max_num
        degree_Lev3?.text = String(degree_array.deg_arry[2])+max_num
        degree_Lev4?.text = String(degree_array.deg_arry[3])+max_num
        degree_Lev5?.text = String(degree_array.deg_arry[4])+max_num
        degree_Lev6?.text = String(degree_array.deg_arry[5])+max_num
        degree_Lev7?.text = String(degree_array.deg_arry[6])+max_num
        degree_Lev8?.text = String(degree_array.deg_arry[7])+max_num
        degree_Lev9?.text = String(degree_array.deg_arry[8])+max_num
        degree_Lev10?.text = String(degree_array.deg_arry[9])+max_num
        degree_Lev11?.text = String(degree_array.deg_arry[10])+max_num
        degree_Lev12?.text = String(degree_array.deg_arry[11])+max_num
    }

@IBAction func back()
{
self.tabBarController?.selectedIndex = 0
}
    

}

