//
//  ViewController.swift
//  Math_test
//
//  Created by m on 7/25/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit
import SwiftGifOrigin
import TextFieldCounter
import MoveViewUpForKeyboardKit

class Main: UIViewController,UITextFieldDelegate {

    /*func xxx()
   {
    let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(Main.dismissKeyboard))
    view.addGestureRecognizer(tap)
    }
    //==========================================
    @objc func dismissKeyboard() {
    OK_BTN()
}*/
    //==========================================
   /* func initialize_views()
    {
        let levels_Tab = self.tabBarController?.viewControllers![1] as! levels
        for item in degree_levels
        {
            levels_Tab.degrees.append(item)
        }
        let scores_Tab = self.tabBarController?.viewControllers![2] as! scores
        for item in degree_levels
        {
            scores_Tab.scores.append(item)
        }
    }*/
    //==========================================
    var Randum_num1=0,Randum_num2=0,Randum_num3=0,Randum_num4=0
    var color1 =  UIColor( red: CGFloat(198/255.0), green: CGFloat(94/255.0), blue: CGFloat(131/255.0), alpha: CGFloat(0.7))
    var color2 =  UIColor( red: CGFloat(198/255.0), green: CGFloat(94/255.0), blue: CGFloat(131/255.0), alpha: CGFloat(1.0))
    var ranges = [[0,10],[0,10],[0,10],[0,10],[0,10],[0,10],[0,10],[0,10],[0,10],[0,10],[0,10],[0,10]]
    //==========================================
    var Ques:String = "..................."
    var ques_answer = 0
    var user_answer = 0
    var messages = ["correct 😎😎","Wrong 😩😭😢","Time out 😂😂"]
    //==========================================
    var levels_names = ["level 1","level 2","level 3","level 4","level 5","level 6","level 7","level 8","level 9","level 10","level 11","level 12"]
    //==========================================
    var current_level = "level 1"
    var current_degree = 0
    var flag_counter = 0
    //==========================================
    private var timer: Timer?
    private var timer2: Timer?
    private var elapsedTimeInSecond: Int = 25
    private var elapsed: Int = 0
    let max_grade_timer2 = 2
    let  max_grade_timer1 = 25
    let max_num_ques = 2
    //==========================================
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var degree_Label: UILabel!
    @IBOutlet weak var message_Label: UILabel!
    @IBOutlet weak var level_Label: UILabel!
    @IBOutlet weak var Question_label: UILabel!
    @IBOutlet weak var replay_level_label: UILabel!
    @IBOutlet weak var answer: UITextField!
    @IBOutlet weak var animationView: UIView!
    @IBOutlet weak var GIF_img: UIImageView!
    @IBOutlet weak var answer_stackView: UIStackView!
    @IBOutlet weak var keyboard_view: UIView!
    @IBOutlet weak var Result_view: UIView!
    @IBOutlet weak var completion_view: UIView!
    @IBOutlet weak var replay_view: UIView!
    @IBOutlet weak var OK: UIButton!
    @IBOutlet weak var start_btn: UIButton!
    //--------------
    @IBOutlet weak var completion_view_level_label: UILabel!
    @IBOutlet weak var completion_view_counter_label: UILabel!
     @IBOutlet weak var completion_view_must_label: UILabel!
    @IBOutlet weak var completion_view_cancel_BTN: UIButton!
    @IBOutlet weak var completion_view_GOlevel_BTN: UIButton!
//==========================================
    override func viewDidLoad() {
        super.viewDidLoad()
        timeLabel.text = String(max_grade_timer1)
        print (degree_array.deg_arry)
        keyboard_view.isHidden = true
        Result_view.isHidden = true
        replay_view.isHidden = true
        level_Label.text = levels_names[0]
        degree_Label.text = String(current_degree)
        answer.text = ""
        Question_label.text = Ques
        OK.isEnabled = false
        completion_view.isHidden = true
        print(ranges[0][0])
        print(ranges[0][1])
    }
//==========================================
    @IBAction func START_QUESTION(sender: UIButton)
{
    if(flag_counter == max_num_ques)
    {
        completion_view_level_label.text = levels_names[current_degree]
        completion_view_counter_label.text = String(flag_counter)
        degree_array.deg_arry[current_degree] = max_num_ques
        current_degree += 1
        flag_counter = 0
        degree_array.deg_arry[current_degree] = flag_counter
        current_level = levels_names[current_degree]
        level_Label.text = levels_names[current_degree]
        completion_view_GOlevel_BTN.setTitle("medo", for: .normal)
        //===============
        completion_view.isHidden = false
    }
    GIF_img.loadGif(name: "GIf")
    sender.isHidden = true
    let x = generate_question(level: level_Label.text!)
    Question_label.text = x.0
    ques_answer = x.1
    startTimer()
    OK.isEnabled = true
}
//==========================================
    @IBAction func OK_BTN()
    {
       /* if(flag_counter == 1)
        {
            completion_view_level_label.text = levels_names[current_degree]
            completion_view_counter_label.text = String(flag_counter)
            degree_levels[current_degree] = 1
            current_degree += 1
            flag_counter = 0
            degree_levels[current_degree] = flag_counter
            current_level = levels_names[current_degree]
            level_Label.text = levels_names[current_degree]
            completion_view_GOlevel_BTN.setTitle(level_Label.text, for: .normal)
            //===============
            completion_view.isHidden = false
        }*/
        if(answer.hasText == true)
        {
        Result_view.isHidden = false
        user_answer = Int(answer.text!)!
        if(user_answer == ques_answer)
        {
           flag_counter += 1
           degree_array.deg_arry[current_degree] = flag_counter
            if (flag_counter == max_num_ques)
            {
                completion_view_level_label.text = levels_names[current_degree]
                completion_view_counter_label.alpha = 0.7
                degree_array.deg_arry[current_degree] = max_num_ques
                current_degree += 1
                flag_counter = 0
               // degree_array.deg_arry[current_degree] = flag_counter
                current_level = levels_names[current_degree]
                level_Label.text = levels_names[current_degree]
//animation
//=================================================
                completion_view_GOlevel_BTN.setTitle(level_Label.text, for: .normal)
                //===============
                completion_view.isHidden = false
                completion_view_GOlevel_BTN.isEnabled = false
                completion_view_cancel_BTN.isEnabled = false
                //==================
                completion_view_level_label.transform = CGAffineTransform.init(scaleX: 0, y: 0)
                
                UIView.animate(withDuration: 3, delay: 0, options: [], animations: {
                    self.completion_view_level_label.transform = .identity
                }, completion: {(true) in
                self.timer_animation()
               // self.completion_view_counter_label.textColor = UIColor.green
               // self.completion_view_must_label.textColor = UIColor.green
                self.completion_view_GOlevel_BTN.isEnabled = true
                self.completion_view_cancel_BTN.isEnabled = true
                }
                )
            }
                
            else
            {
                message_Label.text = messages[0]
                degree_Label.text = String(flag_counter)
            }
            }
         
        
        else
        {
           message_Label.text = messages[1]
           degree_Label.text = String(flag_counter)
        }
        }
        else
        {
         //OK.isEnabled = false
        }
        answer.text = ""
        print(degree_array.deg_arry)
    }
//==========================================
    @IBAction func next_question()
    {
        updateTime2Label()
        completion_view_counter_label.text = "0"
        Result_view.isHidden = true
        completion_view.isHidden = true
        let y = generate_question(level: level_Label.text!)
        Question_label.text = y.0
        ques_answer = y.1
        resetTimer()
    }
//==========================================
    @IBAction func show_levels()
    {

       /* let levels_Tab = self.tabBarController?.viewControllers![1] as! levels
        for item in degree_levels
        {
            levels_Tab.degrees.append(item)
        }*/
       self.tabBarController?.selectedIndex = 1
    }
    
//==========================================
    @IBAction func show_scores()
    {

       
        /*let scores_Tab = self.tabBarController?.viewControllers![2] as! scores
        for item in degree_levels
        {
            scores_Tab.scores.append(item)
        }*/
        self.tabBarController?.selectedIndex = 2

    }
//==========================================
    @IBAction func cancel_btn(_sender: UIButton)
    {
        updateTime2Label()
        completion_view_counter_label.text = "0"
        self.completion_view.isHidden = true
       
        self.Result_view.isHidden = true

        self.replay_view.isHidden = true
        
        start_btn.isHidden = false
        Question_label.text = "..................."
        answer.text = ""
        resetTimer2()
    }
    //==========================================
    @IBAction func replay_level_btn(_sender: UIButton)
    {
        self.replay_view.isHidden = true
        start_btn.isHidden = false
        Question_label.text = "..................."
        answer.text = ""
        resetTimer2()
    }
    //==========================================
    
    
    func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true, block: {
            (timer) in
            if(self.elapsedTimeInSecond == 0 && !self.answer.hasText)
            {
                self.message_Label.text = self.messages[2]
                self.Result_view.isHidden = false
                self.resetTimer2()
            }
           else if(self.elapsedTimeInSecond == 0 && self.answer.hasText)
            {
                self.user_answer = Int(self.answer.text!)!
                if(self.user_answer == self.ques_answer)
                {
                    self.flag_counter += 1
                    degree_array.deg_arry[self.current_degree] = self.flag_counter
                    if (self.flag_counter == self.max_num_ques)
                    {
                        self.self.completion_view_level_label.text = self.levels_names[self.current_degree]
                        self.completion_view_counter_label.text = String(self.flag_counter)
                        degree_array.deg_arry[self.current_degree] = 1
                        self.self.current_degree += 1
                        self.flag_counter = 0
                        degree_array.deg_arry[self.current_degree] = self.flag_counter
                        self.current_level = self.levels_names[self.current_degree]
                        self.level_Label.text = self.levels_names[self.current_degree]
                        //animation
                        //============================================================animation_part
                        self.completion_view_GOlevel_BTN.setTitle(self.level_Label.text, for: .normal)
                        //===============
                        self.completion_view.isHidden = false
                        self.completion_view_GOlevel_BTN.isEnabled = false
                        self.self.completion_view_cancel_BTN.isEnabled = false
                        //==================
                        self.completion_view_level_label.transform = CGAffineTransform.init(scaleX: 0, y: 0)
                        UIView.animate(withDuration: 3, delay: 0, options: [], animations: {
                            self.completion_view_level_label.transform = .identity
                        }, completion: {(true) in
                            self.timer_animation()
                            // self.completion_view_counter_label.textColor = UIColor.green
                            // self.completion_view_must_label.textColor = UIColor.green
                            self.completion_view_GOlevel_BTN.isEnabled = true
                            self.completion_view_cancel_BTN.isEnabled = true
                        }
                        )
                    //============================================================animation_part
                    }
                    else
                    {
                        self.message_Label.text = self.messages[0]
                        self.degree_Label.text = String(self.flag_counter)
                    }
                }
                else
                {
                    self.message_Label.text = self.messages[1]
                    self.degree_Label.text = String(self.flag_counter)
                    
                }
                self.Result_view.isHidden = false
                self.resetTimer2()
            }
            else
            {
            self.elapsedTimeInSecond -= 1
            self.updateTimeLabel()
            }
        })
    }
//==========================================33333333333333333333333====animation_counter
    func timer_animation() {
        timer2 = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true, block: {
            (timer2) in
            if(self.elapsed==self.max_grade_timer2)
            {
               self.completion_view_counter_label.textColor = UIColor.green
               self.completion_view_must_label.textColor = UIColor.green
                self.restar_timer_animation()
                
            }
            else
            {
             self.update_TimeLabel_animation()
            }
        })
    }
    func update_TimeLabel_animation() {
        self.completion_view_counter_label.textColor = color1
        self.completion_view_must_label.textColor = color2
        self.elapsed += 1
        completion_view_counter_label.text = String(self.elapsed)
    }
    func restar_timer_animation()
    {
        timer2?.invalidate()
        elapsed = 0
    }
   func  updateTime2Label()
    {
     self.completion_view_counter_label.textColor = color1
     self.completion_view_must_label.textColor = color2
    }
//==========================================33333333333333333333333====animation_counter
    func resetTimer() {
    timer?.invalidate()
    elapsedTimeInSecond = max_grade_timer1
    updateTimeLabel()
    startTimer()
    }
//==========================================
    func resetTimer2() {
        timer?.invalidate()
        elapsedTimeInSecond = max_grade_timer1
        updateTimeLabel()
    }
//==========================================
    func updateTimeLabel() {
    let seconds = elapsedTimeInSecond % 60
    timeLabel.text = String(format: "%02d", seconds)
    }
//====================================================================================keyboard
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboard_view.isHidden = false
    }
 //---------------
    @IBAction func custom_keyboard(_sender: UIButton)
    {
        answer.isEnabled = true
        if(_sender.currentTitle!=="-" && answer.hasText)
        {
            answer.text = answer.text
        }
       else if(_sender.currentTitle!=="<" && answer.hasText)
        {
           answer.text = ""
            
        }
        else
        {
            answer.text! += _sender.currentTitle!
        }
    }
 //---------------
    @IBAction func ok_keyboard(_sender: UIButton)
    {
        keyboard_view.isHidden = true
        answer.endEditing(true)
    }
    //---------------
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        keyboard_view.isHidden = true
        Result_view.isHidden = true
        answer.endEditing(true)
    }
//====================================================================================keyboard
    
    func generate_question(level: String) -> (String,Int)
    {
        
        
        if (level == "level 1")
        {
         generate_numbers(low_value:ranges[0][0],high_value:ranges[0][1])
         Ques = String(Randum_num1)+"+"+String(Randum_num2)+"+"+String(Randum_num3)
         ques_answer = Int(Randum_num1)+Int(Randum_num2)+Int(Randum_num3)
         return(Ques,ques_answer)
        }
        else if (level == "level 2")
        {
            generate_numbers(low_value:ranges[1][0],high_value: ranges[1][1])
            Ques = String(Randum_num1)+"+"+String(Randum_num2)+"+"+String(Randum_num3)
            ques_answer = Int(Randum_num1)+Int(Randum_num2)+Int(Randum_num3)
            return(Ques,ques_answer)
            
        }
        else if (level == "level 3")
        {
          generate_numbers(low_value:ranges[2][0],high_value:ranges[2][1])
          Ques = String(Randum_num1)+"-"+String(Randum_num2)+"-"+String(Randum_num3)
          ques_answer = Int(Randum_num1)-Int(Randum_num2)-Int(Randum_num3)
          return(Ques,ques_answer)
            
            
        }
        else if (level == "level 4")
        {
            generate_numbers(low_value:ranges[3][0],high_value: ranges[3][1])
            Ques = String(Randum_num1)+"-"+String(Randum_num2)+"-"+String(Randum_num3)
            ques_answer = Int(Randum_num1)-Int(Randum_num2)-Int(Randum_num3)
            return(Ques,ques_answer)
            
            
        }
        else if (level == "level 5")
        {
            generate_numbers(low_value:ranges[4][0],high_value: ranges[4][1])
            Ques = String(Randum_num1)+"-"+String(Randum_num2)+"+"+String(Randum_num3)
            ques_answer = Int(Randum_num1)-Int(Randum_num2)+Int(Randum_num3)
            return(Ques,ques_answer)
            
        }
        else if (level == "level 6")
        {
            generate_numbers(low_value: ranges[5][0],high_value: ranges[5][1])
            Ques = String(Randum_num1)+"+"+String(Randum_num2)+"-"+String(Randum_num3)
            ques_answer = Int(Randum_num1)+Int(Randum_num2)-Int(Randum_num3)
            return(Ques,ques_answer)
            
            
        }
        else if (level == "level 7")
        {
            generate_numbers(low_value:ranges[6][0],high_value: ranges[6][1])
            Ques = String(Randum_num1)+"* 8"
            ques_answer = Int(Randum_num1)*8
            return(Ques,ques_answer)
            
        }
        else if (level == "level 8")
        {
            generate_numbers(low_value:ranges[7][0],high_value: ranges[7][1])
            Ques = String(Randum_num1)+"*"+String(Randum_num2)+"*"+String(Randum_num3)
            ques_answer = Int(Randum_num1)*Int(Randum_num2)*Int(Randum_num3)
            return(Ques,ques_answer)
            
        }
        else if (level == "level 9")
        {
            generate_numbers(low_value: ranges[8][0],high_value: ranges[8][1])
            Ques = String(Randum_num1)+"+"+String(Randum_num2)+"+"+String(Randum_num3)+"*"+String(Randum_num3)
            ques_answer = Int(Randum_num1)+Int(Randum_num2)+Int(Randum_num3)*Int(Randum_num3)
            return(Ques,ques_answer)
        }
        else if (level == "level 10")
        {
            generate_numbers(low_value:ranges[9][0],high_value: ranges[9][1])
            Ques = String(Randum_num1)+"-"+String(Randum_num2)+"-"+String(Randum_num3)+"*"+String(Randum_num3)
            ques_answer = Int(Randum_num1)-Int(Randum_num2)-Int(Randum_num3)*Int(Randum_num3)
            return(Ques,ques_answer)
        }
        else if (level == "level 11")
        {
            generate_numbers(low_value: ranges[10][0],high_value: ranges[10][1])
            Ques = String(Randum_num1)+"+"+String(Randum_num2)+"-"+String(Randum_num3)+"*"+String(Randum_num3)
            ques_answer = Int(Randum_num1)+Int(Randum_num2)-Int(Randum_num3)*Int(Randum_num3)
            return(Ques,ques_answer)
            
        }
        else if (level == "level 12")
        {
            generate_numbers(low_value:ranges[11][0],high_value: ranges[11][1])
            Ques = String(Randum_num1)+"-"+String(Randum_num2)+"+"+String(Randum_num3)+"+"+String(Randum_num3)
            ques_answer = Int(Randum_num1)-Int(Randum_num2)+Int(Randum_num3)*Int(Randum_num3)
            return(Ques,ques_answer)
        }
        return ("level not_found",0)
    }
//====================================================================================
    func generate_numbers(low_value: Int,high_value: Int)
    {
        Randum_num1 = Int(arc4random_uniform(UInt32(high_value-low_value + 1))) + low_value
        Randum_num2 = Int(arc4random_uniform(UInt32(high_value-low_value + 1))) + low_value
        Randum_num3 = Int(arc4random_uniform(UInt32(high_value-low_value + 1))) + low_value
        Randum_num4 = Int(arc4random_uniform(UInt32(high_value-low_value + 1))) + low_value
    }
    }
    
    
    

/*extension UIViewController {
    
    func hideCustomKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        //tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
    
        
}
}*/
//animation concepts
//=============================================================================

/*   UIView.animate(withDuration: 2, delay: 5, options: [], animations: {
 UIView.setAnimationRepeatCount(5)
 self.completion_view_counter_label.text = String(self.counter_animation)
 self.completion_view_counter_label.alpha=0.6
 self.completion_view_counter_label.transform = .identity
 }, completion:
 
 { (true) in
 self.completion_view_counter_label.alpha=1
 self.completion_view_counter_label.textColor = UIColor.green
 self.completion_view_must_label.textColor = UIColor.green
 }
 )*/
//=======================================================================================
    




