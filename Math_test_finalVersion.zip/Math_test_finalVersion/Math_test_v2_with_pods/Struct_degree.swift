//
//  Struct_degree.swift
//  Math_test_v2_with_pods
//
//  Created by m on 9/6/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import Foundation
struct degree_array {
   static var deg_arry = [0,0,0,0,0,0,0,0,0,0,0,0]
   static let levels_Names = ["level 1","level 2","level 3","level 4","level 5","level 6","level 7","level 8","level 9","level 10","level 11","level 12"]
    
}
