//
//  completion_view.swift
//  Math_test_v2_with_pods
//
//  Created by m on 9/5/18.
//  Copyright © 2018 WzyoU. All rights reserved.
//

import UIKit
@IBDesignable
class replay_view: UIView {

    @IBOutlet weak var completion_view_level_label: UILabel!
    @IBOutlet weak var completion_view_counter_label: UILabel!
    @IBOutlet weak var completion_view_cancel_BTN: UIButton!
    @IBOutlet weak var completion_view_GOlevel_BTN: UIButton!
    
    

    
}
